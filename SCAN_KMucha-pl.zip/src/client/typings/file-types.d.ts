declare module '*.ttf';
