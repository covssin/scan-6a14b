import { Card } from 'client/components/Form/Card';
import Row from 'client/components/Form/Row';

const BlockListsCard = (props: { data: any; title: string; actionButtons: any }): JSX.Element => {
  const blockLists = props.data.blocklists;
  return (
    <Card heading={props.title} actionButtons={props.actionButtons}>
      {blockLists.map((blocklist: any, blockIndex: number) => (
        <Row
          title={blocklist.serverIp}
          lbl={blocklist.server}
          val={!blocklist.isBlocked}
          yes="Brak blokady"
          no="Zablokowano"
          term="dns-blocklist"
          key={`blocklist-${blockIndex}-${blocklist.serverIp}`}
        />
      ))}
    </Card>
  );
};

export default BlockListsCard;
