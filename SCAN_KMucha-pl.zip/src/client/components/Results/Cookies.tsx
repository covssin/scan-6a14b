import { Card } from 'client/components/Form/Card';
import Row, { ExpandableRow } from 'client/components/Form/Row';
import { fromFindings } from 'client/components/misc/Icon';
import type { Cookie } from 'client/utils/result-processor';
import { checkCookie } from 'client/analysis/rules/cookies';

export const parseHeaderCookies = (cookiesHeader: string[]): Cookie[] => {
  if (!cookiesHeader || !cookiesHeader.length) return [];
  const cookies = cookiesHeader.flatMap((cookieHeader) => {
    return cookieHeader.split(/,(?=\s[A-Za-z0-9]+=)/).map((cookieString) => {
      const [nameValuePair, ...attributePairs] = cookieString
        .split('; ')
        .map((part) => part.trim());
      const [name, ...valueParts] = nameValuePair.split('=');
      const value = valueParts.join('=');
      const attributes: Record<string, string> = {};
      attributePairs.forEach((pair) => {
        const [attributeName, attributeValue = ''] = pair.split('=');
        attributes[attributeName] = attributeValue;
      });
      return { name, value, attributes };
    });
  });
  return cookies;
};

// A cookie's status, from the security flags it's missing
const cookieStatus = ({ name, attributes }: Cookie) => {
  const flags = Object.keys(attributes).map((key) => key.toLowerCase());
  return fromFindings(checkCookie(name, flags));
};

const CookiesCard = (props: { data: any; title: string; actionButtons: any }): JSX.Element => {
  const headerCookies = parseHeaderCookies(props.data.headerCookies) || [];
  const clientCookies = props.data.clientCookies || [];
  const noCookies = !headerCookies.length && !clientCookies.length;
  return (
    <Card heading={props.title} actionButtons={props.actionButtons}>
      {noCookies && <Row lbl="Pliki cookie" val="Brak" />}
      {headerCookies.map((cookie, index) => {
        const attributes = Object.keys(cookie.attributes).map((key: string) => {
          return { lbl: key, val: cookie.attributes[key] || true };
        });
        return (
          <ExpandableRow
            key={`header-cookie-${index}-${cookie.name}`}
            lbl={cookie.name || '(bez nazwy)'}
            val={cookie.value}
            term="cookie-security"
            {...cookieStatus(cookie)}
            rowList={attributes}
          />
        );
      })}
      {clientCookies.map((cookie: any, index: number) => {
        const nameValPairs = Object.keys(cookie).map((key: string) => {
          return { lbl: key, val: String(cookie[key]) };
        });
        return (
          <ExpandableRow
            key={`client-cookie-${index}-${cookie.name}`}
            lbl={cookie.name}
            rowList={nameValPairs}
          />
        );
      })}
    </Card>
  );
};

export default CookiesCard;
