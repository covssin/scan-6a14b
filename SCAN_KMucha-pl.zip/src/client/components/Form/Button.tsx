import { type ReactNode, type MouseEventHandler } from 'react';

import styled from '@emotion/styled';
import { keyframes } from '@emotion/react';
import colors from 'client/styles/colors';
import { type InputSize, applySize } from 'client/styles/dimensions';

type LoadState = 'loading' | 'success' | 'error';

interface ButtonProps {
  children: ReactNode;
  onClick?: MouseEventHandler<HTMLButtonElement>;
  size?: InputSize;
  bgColor?: string;
  fgColor?: string;
  styles?: string;
  title?: string;
  type?: 'button' | 'submit' | 'reset' | undefined;
  loadState?: LoadState;
}

const StyledButton = styled.button<ButtonProps>`
  cursor: pointer;
  border: none;
  border-radius: 0.25rem;
  font-family: var(--font-mono);
  box-sizing: border-box;
  width: -moz-available;
  display: flex;
  justify-content: center;
  gap: 1rem;
  transition: background 0.3s ease;
  &:hover {
    background: ${colors.textColor};
  }
  ${(props) => applySize(props.size)};
  ${(props) => (props.bgColor ? `background: ${props.bgColor};` : `background: ${colors.primaryIncreasedContrast};`)}
  ${(props) => (props.fgColor ? `color: ${props.fgColor};` : `color: ${colors.background};`)}
  ${(props) => props.styles}
`;

const spinAnimation = keyframes`
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
`;
const SimpleLoader = styled.div`
  border: 4px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top: 4px solid ${colors.background};
  width: 1rem;
  height: 1rem;
  animation: ${spinAnimation} 1s linear infinite;
`;

const Loader = (props: { loadState: LoadState }) => {
  if (props.loadState === 'loading') return <SimpleLoader />;
  if (props.loadState === 'success') return <span>✔</span>;
  if (props.loadState === 'error') return <span>✗</span>;
  return <span></span>;
};

const Button = (props: ButtonProps): JSX.Element => {
  const { children, size, bgColor, fgColor, onClick, styles, title, loadState, type } = props;
  return (
    <StyledButton
      onClick={onClick || (() => null)}
      size={size}
      bgColor={bgColor}
      fgColor={fgColor}
      styles={styles}
      title={title?.toString()}
      type={type || 'button'}
    >
      {loadState && <Loader loadState={loadState} />}
      {children}
    </StyledButton>
  );
};

export default Button;
