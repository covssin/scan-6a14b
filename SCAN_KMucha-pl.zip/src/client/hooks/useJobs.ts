import { useReducer, useEffect, useRef, useCallback, useState } from 'react';
import { logJobOutcome } from 'client/utils/logger';
import keys from 'client/utils/get-keys';
import type { AddressType } from 'client/utils/address-type-checker';
import type { LoadingState } from 'client/components/misc/ProgressBar';
import type { JobSpec, JobContext, JobsState } from 'client/jobs/types';

type Action =
  | { type: 'start'; cardIds: string[] }
  | { type: 'success'; cardIds: string[]; raw: any; timeTaken: number }
  | {
      type: 'error';
      cardIds: string[];
      outcome: 'error' | 'timed-out';
      error: string;
      timeTaken: number;
    }
  | { type: 'skipped'; cardIds: string[]; reason?: string }
  | { type: 'force'; cardId: string; state: LoadingState };

const initialState = (jobs: JobSpec[]): JobsState =>
  Object.fromEntries(
    jobs.flatMap((j) => j.cards.map((c) => [c.id, { state: 'loading' as LoadingState }])),
  );

const setMany = (s: JobsState, ids: string[], patch: Partial<JobsState[string]>) =>
  ids.reduce((acc, id) => ({ ...acc, [id]: { ...acc[id], ...patch } }), s);

const reducer = (s: JobsState, a: Action): JobsState => {
  switch (a.type) {
    case 'start':
      return setMany(s, a.cardIds, { state: 'loading', error: undefined });
    case 'success':
      return setMany(s, a.cardIds, {
        state: 'success',
        raw: a.raw,
        timeTaken: a.timeTaken,
        error: undefined,
      });
    case 'error':
      return setMany(s, a.cardIds, {
        state: a.outcome,
        error: a.error,
        timeTaken: a.timeTaken,
      });
    case 'skipped':
      return setMany(s, a.cardIds, { state: 'skipped', error: a.reason });
    case 'force':
      return { ...s, [a.cardId]: { ...s[a.cardId], state: a.state } };
  }
};

const isTimeout = (msg = '') => /timed[- ]?out/i.test(msg);

const noIpMsg = "Pominięto, ponieważ nie udało się ustalić adresu IP celu";

const apiBase = (import.meta.env.PUBLIC_API_ENDPOINT || '/api') as string;

// Drives every job's lifecycle: fetch, retry, abort, fallback promotion
const useJobs = (address: string, addressType: AddressType, jobs: JobSpec[]) => {
  const [state, dispatch] = useReducer(reducer, jobs, initialState);
  const [ipAddress, setIpAddress] = useState<string | undefined>();
  const [ipLookupError, setIpLookupError] = useState<string | undefined>();
  const startTime = useRef(Date.now()).current;
  const controllers = useRef<Record<string, AbortController>>({});
  const fired = useRef<Set<string>>(new Set());
  const stateRef = useRef(state);
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  const skipJob = useCallback((job: JobSpec, reason?: string) => {
    const cardIds = job.cards.map((c) => c.id);
    if (cardIds.length) dispatch({ type: 'skipped', cardIds, reason });
  }, []);

  // When get-ip comes back empty, skip the jobs that needed the IP
  const skipIpJobs = useCallback(
    (reason?: string) => jobs.filter((j) => j.needsIp).forEach((j) => skipJob(j, reason)),
    [jobs, skipJob],
  );

  const runJob = useCallback(
    (job: JobSpec, ip?: string) => {
      const cardIds = job.cards.map((c) => c.id);
      controllers.current[job.id]?.abort();
      const controller = new AbortController();
      controllers.current[job.id] = controller;
      fired.current.add(job.id);

      if (cardIds.length) dispatch({ type: 'start', cardIds });

      const ctx: JobContext = { address, ipAddress: ip, api: apiBase, signal: controller.signal };
      job
        .fetcher(ctx)
        .then((raw: any) => {
          if (controller.signal.aborted) return;
          const timeTaken = Date.now() - startTime;
          if (job.id === 'get-ip') {
            if (typeof raw === 'string') {
              setIpAddress(raw);
              return;
            }
            if (raw?.error) setIpLookupError(raw.error);
            skipIpJobs(raw?.skipped || noIpMsg);
            return;
          }
          if (raw?.skipped) {
            dispatch({ type: 'skipped', cardIds, reason: raw.skipped });
            cardIds.forEach((id) => logJobOutcome('error', id, timeTaken, raw.skipped));
            return;
          }
          if (raw?.error) {
            const outcome = isTimeout(raw.error) ? 'timed-out' : 'error';
            dispatch({ type: 'error', cardIds, outcome, error: raw.error, timeTaken });
            cardIds.forEach((id) => logJobOutcome(outcome, id, timeTaken, raw.error));
            return;
          }
          dispatch({ type: 'success', cardIds, raw, timeTaken });
          cardIds.forEach((id) => logJobOutcome('success', id, timeTaken));
        })
        .catch((err: any) => {
          if (controller.signal.aborted || err?.name === 'AbortError') return;
          const timeTaken = Date.now() - startTime;
          const message = err?.message || 'Nieznany błąd';
          if (job.id === 'get-ip') {
            skipIpJobs(noIpMsg);
            return;
          }
          const outcome = isTimeout(message) ? 'timed-out' : 'error';
          dispatch({ type: 'error', cardIds, outcome, error: message, timeTaken });
          cardIds.forEach((id) => logJobOutcome(outcome, id, timeTaken, message));
        });
    },
    [address, startTime, skipIpJobs],
  );

  // Decide which jobs are eligible for the current input
  const eligible = useCallback(
    (job: JobSpec) => {
      if (job.needsIp) {
        return addressType === 'url' || addressType === 'ipV4' || addressType === 'ipV6';
      }
      if (!job.expectedAddressTypes) return true;
      return job.expectedAddressTypes.includes(addressType);
    },
    [addressType],
  );

  const skipReason = useCallback(
    (job: JobSpec): string => {
      const allowed = job.expectedAddressTypes;
      if (allowed && !allowed.includes(addressType)) {
        if (addressType === 'ipV4' || addressType === 'ipV6') {
          return 'Ten test wymaga nazwy domenowej i nie może zostać uruchomiony dla samego adresu IP';
        }
        return `Ten test jest dostępny wyłącznie dla danych wejściowych typu: ${allowed.join(', ')}`;
      }
      return 'Ten test nie ma zastosowania dla podanego formatu danych';
    },
    [addressType],
  );

  // Initial fan-out: fire non-IP jobs immediately, mark unsupported as skipped
  useEffect(() => {
    if (keys.disableEverything) {
      const reason = 'Narzędzie SCAN_KMucha zostało tymczasowo wyłączone na tej instancji';
      jobs.forEach((j) => skipJob(j, reason));
      return;
    }
    if (!address || addressType === 'empt' || addressType === 'err') return;

    fired.current.clear();
    setIpLookupError(undefined);
    if (addressType === 'ipV4' || addressType === 'ipV6') setIpAddress(address);
    else setIpAddress(undefined);

    jobs.forEach((job) => {
      if (!eligible(job)) {
        skipJob(job, skipReason(job));
        return;
      }
      if (job.needsIp) return;
      runJob(job);
    });

    return () => {
      Object.values(controllers.current).forEach((c) => c.abort());
      controllers.current = {};
    };
  }, [address, addressType, jobs, runJob, skipJob, eligible, skipReason]);

  // Fire IP-dependent jobs the moment we have an IP, but only once each
  useEffect(() => {
    if (!ipAddress) return;
    jobs.forEach((job) => {
      if (!job.needsIp || fired.current.has(job.id)) return;
      if (!eligible(job)) {
        skipJob(job, skipReason(job));
        return;
      }
      runJob(job, ipAddress);
    });
  }, [ipAddress, jobs, runJob, skipJob, eligible, skipReason]);

  // Promote any card whose fallback resolves after the primary failed
  useEffect(() => {
    jobs.forEach((job) =>
      job.cards.forEach((card) => {
        if (!card.fallback) return;
        const entry = state[card.id];
        if (!entry || entry.state === 'success' || entry.state === 'loading') return;
        if (card.fallback(state)) dispatch({ type: 'force', cardId: card.id, state: 'success' });
      }),
    );
  }, [state, jobs]);

  // Single client-side budget for stuck jobs, resets on new input
  useEffect(() => {
    if (!address || addressType === 'empt' || addressType === 'err') return;
    const budget = parseInt((import.meta.env.PUBLIC_API_TIMEOUT_LIMIT as string) || '45000', 10);
    const timer = setTimeout(() => {
      const stuck = Object.entries(stateRef.current)
        .filter(([id, e]) => {
          if (e?.state !== 'loading') return false;
          const owner = jobs.find((j) => j.cards.some((c) => c.id === id));
          return !owner?.noClientTimeout;
        })
        .map(([id]) => id);
      if (!stuck.length) return;
      dispatch({
        type: 'error',
        cardIds: stuck,
        outcome: 'timed-out',
        error: 'Przekroczono limit czasu oczekiwania po stronie klienta',
        timeTaken: Date.now() - startTime,
      });
      stuck.forEach((id) => {
        const owner = jobs.find((j) => j.cards.some((c) => c.id === id));
        if (owner) controllers.current[owner.id]?.abort();
      });
    }, budget);
    return () => clearTimeout(timer);
  }, [address, addressType, jobs, startTime]);

  const retry = useCallback(
    (cardId: string) => {
      if (state[cardId]?.state === 'loading') return;
      const job = jobs.find((j) => j.cards.some((c) => c.id === cardId));
      if (!job) return;
      runJob(job, ipAddress);
    },
    [jobs, runJob, state, ipAddress],
  );

  return { state, retry, ipLookupError };
};

export default useJobs;
