import middleware from './_common/middleware.js';
import { httpGet } from './_common/http.js';

const convertTimestampToDate = (timestamp) => {
  const [year, month, day, hour, minute, second] = [
    timestamp.slice(0, 4),
    timestamp.slice(4, 6) - 1,
    timestamp.slice(6, 8),
    timestamp.slice(8, 10),
    timestamp.slice(10, 12),
    timestamp.slice(12, 14),
  ].map((num) => parseInt(num, 10));

  return new Date(Date.UTC(year, month, day, hour, minute, second));
};

const countPageChanges = (results) => {
  let prevDigest = null;
  return results.reduce((acc, curr) => {
    if (curr[2] !== prevDigest) {
      prevDigest = curr[2];
      return acc + 1;
    }
    return acc;
  }, -1);
};

const getAveragePageSize = (scans) => {
  const totalSize = scans.map((scan) => parseInt(scan[3], 10)).reduce((sum, size) => sum + size, 0);
  return Math.round(totalSize / scans.length);
};

const getScanFrequency = (firstScan, lastScan, totalScans, changeCount) => {
  const formatToTwoDecimal = (num) => parseFloat(num.toFixed(2));

  const dayFactor = (lastScan - firstScan) / (1000 * 60 * 60 * 24);
  const daysBetweenScans = formatToTwoDecimal(dayFactor / totalScans);
  const daysBetweenChanges = formatToTwoDecimal(dayFactor / changeCount);
  const scansPerDay = formatToTwoDecimal((totalScans - 1) / dayFactor);
  const changesPerDay = formatToTwoDecimal(changeCount / dayFactor);
  return {
    daysBetweenScans,
    daysBetweenChanges,
    scansPerDay,
    changesPerDay,
  };
};

const wayBackHandler = async (url) => {
  // collapse=timestamp:8 returns one row per archived day, slashing payloads
  // (Wikipedia: 25MB/373k rows -> 428KB/6k rows) without losing first/last/change counts
  const cdxUrl =
    `https://web.archive.org/cdx/search/cdx?url=${encodeURIComponent(url)}` +
    `&output=json&fl=timestamp,statuscode,digest,length&collapse=timestamp:8`;

  try {
    const { data } = await httpGet(cdxUrl);

    if (!data || !Array.isArray(data) || data.length <= 1) {
      return { skipped: 'Site has never before been archived via the Wayback Machine' };
    }

    data.shift();

    const firstScan = convertTimestampToDate(data[0][0]);
    const lastScan = convertTimestampToDate(data[data.length - 1][0]);
    const daysArchived = data.length;
    const changeCount = countPageChanges(data);
    return {
      firstScan,
      lastScan,
      daysArchived,
      changeCount,
      averagePageSize: getAveragePageSize(data),
      scanFrequency: getScanFrequency(firstScan, lastScan, daysArchived, changeCount),
      scanUrl: url,
    };
  } catch (err) {
    return { error: `Error fetching Wayback data: ${err.message}` };
  }
};

export const handler = middleware(wayBackHandler);
export default handler;
