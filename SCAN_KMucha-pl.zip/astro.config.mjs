import { fileURLToPath } from 'node:url';
import { defineConfig } from 'astro/config';
import { loadEnv } from 'vite';

// Integrations
import svelte from '@astrojs/svelte';
import react from '@astrojs/react';
import sitemap from '@astrojs/sitemap';

// Adapters
import vercelAdapter from '@astrojs/vercel';
import netlifyAdapter from '@astrojs/netlify';
import nodeAdapter from '@astrojs/node';

// Pre-load .env so values are available in this config, before Vite
const fileEnv = loadEnv(process.env.NODE_ENV || 'development', process.cwd(), '');

// Read an env var, preferring shell over .env, with a final fallback
const unwrapEnvVar = (varName, fallbackValue) =>
  process.env[varName] ?? fileEnv[varName] ?? fallbackValue;

// Infer the platform from the env vars they set
const guessPlatform = () => {
  if (process.env.VERCEL) return 'vercel';
  if (process.env.NETLIFY) return 'netlify';
  return 'node';
};

// Determine the deploy target (vercel, netlify, node)
const deployTarget = unwrapEnvVar('PLATFORM', guessPlatform()).toLowerCase();

// Determine the output mode (static or server). Mixed prerender supported in static mode
const output = unwrapEnvVar('OUTPUT', 'static');

// The FQDN of where the site is hosted (used for sitemaps & canonical URLs)
const site = unwrapEnvVar('SITE_URL', 'https://web-check.xyz');

// The base URL of the site (if serving from a subdirectory)
const base = unwrapEnvVar('BASE_URL', '/');

// Should run the app in boss-mode (requires extra configuration)
const isBossServer = unwrapEnvVar('BOSS_SERVER', false) === 'true';

// Give check, build and sync their own Vite cache, so they don't overwrite dev's deps
const separateBuildCache = {
  name: 'separate-build-cache',
  hooks: {
    'astro:config:setup': ({ command, updateConfig }) => {
      if (command !== 'dev') updateConfig({ vite: { cacheDir: 'node_modules/.vite-build' } });
    },
  },
};

// Drop the trailing slash from sitemap URLs, so they match canonicals and links
const dropTrailingSlash = (item) => {
  const url = new URL(item.url);
  url.pathname = url.pathname.replace(/\/$/, '');
  return { ...item, url: url.href };
};

// Initialize Astro integrations
const integrations = [
  svelte(),
  react(),
  sitemap({ filter: (page) => !page.includes('/account'), serialize: dropTrailingSlash }),
  separateBuildCache,
];

// Set the appropriate adapter, based on the deploy target
function getAdapter(target) {
  switch (target) {
    case 'vercel':
      return vercelAdapter();
    case 'netlify':
      return netlifyAdapter();
    case 'node':
      return nodeAdapter({ mode: 'middleware' });
    default:
      throw new Error(`Unsupported deploy target: ${target}`);
  }
}
const adapter = getAdapter(deployTarget);

// Print build information to console
console.log(
  `\n\x1b[1m\x1b[35m Preparing to start build of Web Check.... \x1b[0m\n`,
  `\x1b[35m\x1b[2mCompiling for "${deployTarget}" using "${output}" mode, ` +
    `to deploy to "${site}" at "${base}"\x1b[0m\n`,
  `\x1b[2m\x1b[36m🛟 For documentation and support, visit the GitHub repo: ` +
    `https://github.com/lissy93/web-check \n`,
  `💖 Found Web-Check useful? Consider sponsoring us on GitHub ` +
    `to help fund maintenance & development.\x1b[0m\n`,
);

const redirects = {
  '/check/about': '/checks',
};

// Skip the marketing homepage for self-hosted users
if (!isBossServer) {
  redirects['/'] = '/check';
}

// Resolve the @styles alias for sass @use (rolldown-vite needs it set explicitly)
const stylesDir = fileURLToPath(new URL('./src/styles', import.meta.url));

// View transition modules ClientRouter loads, for Vite to pre-bundle in dev
const transitionModules = [
  'astro/virtual-modules/transitions-events.js',
  'astro/virtual-modules/transitions-router.js',
  'astro/virtual-modules/transitions-swap-functions.js',
  'astro/virtual-modules/transitions-types.js',
];

// Export Astro configuration
export default defineConfig({
  output,
  base,
  integrations,
  site,
  adapter,
  redirects,
  vite: {
    resolve: { alias: { '@styles': stylesDir } },
    optimizeDeps: { include: transitionModules },
  },
});
